const loading = document.getElementById('loading-gif');
const card = document.getElementsByClassName('meal');

if(loading) {
   setTimeout(() => {
      window.location.replace('/foods');
   }, 3000);
}

